package labubu.popmart.labublog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabublogApplicationTests {

	@Test
	void contextLoads() {
	}

}
